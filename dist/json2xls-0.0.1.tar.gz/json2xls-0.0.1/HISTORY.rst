.. :changelog:

History
-------

0.0.1 (2014-09-23)
---------------------

* First release on PyPI.